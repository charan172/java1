import java.util.Scanner;


public class StringOperations {

	public static void main(String[] args) {
		Scanner s = new Scanner(System.in);
		System.out.println("Enter a String");
		String newString = s.next();
		System.out.println("Select an Option\nOptions are\n1. Add the String to itself\n"
				+ "2. Replace odd positions with #"
				+"\n3.Remove duplicate characters in the String"
				+"\n4.Change odd characters to uppercase");
		int option = s.nextInt();
		if(option==1)
			System.out.println(newString.concat(newString));
		else if(option==2)
			for (int i=0; i < newString.length(); i++){
		        if (i % 2 != 0)
		          newString = newString.substring(0,i-1) + "#" + newString.substring(i, newString.length());
			System.out.println(newString);
		}
        else if(option==4){
			for (int i=0; i < newString.length(); i++)
		        if (i % 2 != 0)
		        	newString = newString.toUpperCase();
			System.out.println(newString);
        }
		s.close();
	}
			
}


