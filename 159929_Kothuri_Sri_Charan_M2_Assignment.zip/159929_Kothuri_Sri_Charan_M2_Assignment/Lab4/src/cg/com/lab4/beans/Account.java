package cg.com.lab4.beans;

public abstract class Account {
	private long accNum;
	private double balance;
	private Person accHolder;
	private static int accCounter =101;
	public abstract void deposit(double amt) ;
	public abstract  void withdraw(double amt) ;
	public  abstract double calculateBalance() ;
	public long getAccNum() {
		return accNum;
	}
	public void setAccNum(long accNum) {
		this.accNum = accNum;
	}
	public double getBalance() {
		return balance;
	}
	public void setBalance(double balance) {
		this.balance = balance;
	}
	public Person getAccHolder() {
		return accHolder;
	}
	public void setAccHolder(Person accHolder) {
		this.accHolder = accHolder;
	}
	public Account(double balance, Person accHolder) {
		super();
		this.accNum = accCounter++;
		this.balance = balance;
		this.accHolder = accHolder;
	}
	@Override
	public String toString() {
		return "AccNum=" + accNum + ", Balance=" + balance
				+ ", AccHolder " + accHolder;
	}
	
	
}
