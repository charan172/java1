package cg.com.lab4.beans;

public class SavingsAccount extends Account{
	public SavingsAccount(double balance, Person accHolder) {
		super(balance, accHolder);
		// TODO Auto-generated constructor stub
	}

	private final double minBalance=500;

	@Override
	public void withdraw(double amt) {
		if(this.getBalance()-amt>minBalance){
			this.setBalance(this.getBalance()-amt);
			System.out.println("Withdrawal Successful");
		}
		else 
			System.out.println("Sorry! Not enough Balance.\nTransaction Failed");
		
	}

	@Override
	public void deposit(double amt) {
		this.setBalance(this.getBalance()+amt);
		
	}

	@Override
	public double calculateBalance() {
		// TODO Auto-generated method stub
		return 0;
	}

	
}
