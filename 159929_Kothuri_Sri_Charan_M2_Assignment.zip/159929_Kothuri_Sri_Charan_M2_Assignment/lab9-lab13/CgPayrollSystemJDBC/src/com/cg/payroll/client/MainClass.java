package com.cg.payroll.client;
import com.cg.payroll.beans.*;
import com.cg.payroll.exceptions.*;
import com.cg.payroll.services.*;
public class MainClass {
	public static void main(String[] args) throws PayrollServicesDownException,AssociateDetailsNotFoundException{
		PayrollServices payrollServices = new PayrollServicesImpl();
		int associateId=payrollServices.acceptAssociateDetails(2000,"Sri","Charan","Chemical","Sr.Con","157355","sasdbf4@gmail.com" ,991,"KMB","KMB5456",514236, 1974,17843);
		payrollServices.calculateNetSalary(associateId);
		Associate associate=payrollServices.getAssociateDetails(associateId);
		System.out.println(associate.toString());
	}
}