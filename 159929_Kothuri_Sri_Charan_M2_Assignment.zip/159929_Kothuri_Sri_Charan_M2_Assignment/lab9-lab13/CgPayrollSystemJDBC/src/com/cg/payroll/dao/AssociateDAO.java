package com.cg.payroll.dao;
import java.sql.SQLException;
import java.util.ArrayList;
import com.cg.payroll.beans.Associate;
public interface AssociateDAO {
	Associate save(Associate associate) throws SQLException;
	Associate findOne(int associateId) throws SQLException;
	ArrayList<Associate> findAll() throws SQLException;
	boolean update(int associateID, int hra, int conveyenceAllowance,
			int otherAllowance, int personalAllowance, int monthlyTax,
			int gratuity, int grossSalary, int netSalary) throws SQLException;
}